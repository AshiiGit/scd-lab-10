class lab1_q5 {
    public static void main(String[] args) {
        // Letter F
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == 0 || j == 0) {
                    System.out.print("*");
                } else if (i == 2) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        System.out.println();

        // Letter A
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == 0 || j == 0 || j == 4 || i == 2) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        System.out.println();

        // Letter S
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == 0 || i == 2 || i == 4 || (i == 1 && j == 0) || (i == 3 && j == 4)) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        System.out.println();

        // Letter T

        for (int i = 0; i < 7; i++) { // Adjust the height of the 'T' here (7 in this example)
            if (i == 0) {
                for (int j = 0; j < 7; j++) {
                    System.out.print("*");
                }
            } else {
                for (int j = 0; j < 7; j++) {
                    if (j == 3) {
                        System.out.print("*");
                    } else {
                        System.out.print(" ");
                    }
                }
            }
            System.out.println();
        }
    }
}
