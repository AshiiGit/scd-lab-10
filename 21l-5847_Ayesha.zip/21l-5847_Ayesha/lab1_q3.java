/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1javaa;
import java.util.*;
/**
 *
 * @author fast
 */
public class lab1_q3 {
    public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
         System.out.println("Enter a digit between 0 and 1000: ");
         int no = s.nextInt();
         String result = Integer.toString(no);
         int sum = 0;
         for(int i =0;i<result.length();i++)
         {
             char digit = result.charAt(i);
             int digitt = Character.getNumericValue(digit);
             sum = sum + digitt;
         }
         System.out.println(sum);
      
      }
    
}
