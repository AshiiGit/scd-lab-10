/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1javaa;
import java.util.*;
/**
 *
 * @author fast
 */
public class Lab1javaa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
         System.out.println("Enter a number: ");
         int no = s.nextInt();
         for(int i =1;i<10;i++)
         {
             int result = no * i;
             System.out.println(no + "x" + i + "=" + result);
         }
        // TODO code application logic here
    }
    
}
