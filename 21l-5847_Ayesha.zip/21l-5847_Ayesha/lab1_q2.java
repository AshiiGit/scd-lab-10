/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1javaa;
import java.util.*;
/**
 *
 * @author fast
 */
public class lab1_q2 {
      public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
         System.out.println("Enter a degree in Farenhiet: ");
         float no = s.nextFloat();
         float celcius = (no-32)* 5/9;
         System.out.println(celcius);
      }
}
