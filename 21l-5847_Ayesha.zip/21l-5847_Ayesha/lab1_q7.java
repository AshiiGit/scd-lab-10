
import java.util.*;

public class lab1_q7 {
     public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
         System.out.println("Enter the first operand");
         int a = s.nextInt();
         System.out.println("Enter the second operand");
         int b = s.nextInt();
         s.nextLine();
         System.out.print("Enter the operation you want to perform: ");
         String result = s.nextLine();
         int r = 0;
        switch(result)
                 {
            case "/":
                 r = a/b;
                 System.out.println(r);
                 break;
            case "*":
                 r = a*b;
               System.out.println(r);
               break;
            case "+":
               r = a+b;
                 System.out.println(r);
                break;
            case "-":
               r = a - b;
                 System.out.println(r);
               break;
               
       }
        
      
      }
    
    
}